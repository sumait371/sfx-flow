export const PLANS = {
  basic: {
    name: "Basic",
    amount: 19900,
    display: "₹199/month",
    env: "RAZORPAY_BASIC_PLAN_ID"
  },
  premium: {
    name: "Premium",
    amount: 29900,
    display: "₹299/month",
    env: "RAZORPAY_PREMIUM_PLAN_ID"
  }
} as const;

export type PlanKey = keyof typeof PLANS;
