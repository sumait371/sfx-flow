"use client";
import { useState } from "react";

declare global { interface Window { Razorpay:any } }

export default function SubscriptionButton({plan}:{plan:"basic"|"premium"}) {
 const [loading,setLoading]=useState(false);
 async function start(){
  setLoading(true);
  try {
   const res=await fetch("/api/razorpay/create-subscription",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({plan})});
   const data=await res.json();
   if(!res.ok){alert(data.error||"Unable to start checkout");return;}
   if(!document.querySelector('script[src="https://checkout.razorpay.com/v1/checkout.js"]')){
    await new Promise<void>((resolve,reject)=>{const script=document.createElement("script");script.src="https://checkout.razorpay.com/v1/checkout.js";script.onload=()=>resolve();script.onerror=()=>reject(new Error("Razorpay Checkout failed to load"));document.body.appendChild(script);});
   }
   const rzp=new window.Razorpay({
    key:data.key,
    subscription_id:data.subscriptionId,
    name:"SFX FLOW",
    description:`${data.planName} — 7-day free trial`,
    image:"/sfx-flow-logo.png",
    prefill:{name:data.name,email:data.email},
    notes:{plan:data.planName,flow:"UPI AutoPay preferred"},
    theme:{color:"#d5a944"},
    modal:{ondismiss:()=>setLoading(false)},
    handler:async(response:any)=>{
      const verify=await fetch("/api/razorpay/verify",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(response)});
      const out=await verify.json();
      if(out.ok){location.href="/dashboard?payment=success"}else{alert(out.error||"Payment verification failed");setLoading(false)}
    }
   });
   rzp.open();
  } catch(e){alert("Unable to open Razorpay checkout. Please try again.");setLoading(false)}
 }
 return <button className="btn gold full" onClick={start} disabled={loading}>{loading?"Opening Razorpay…":"Continue with UPI AutoPay"}</button>
}
