 "use client";
import { useState } from "react";
import { createClient } from "@/lib/supabase-browser";
import { useRouter } from "next/navigation";
import Link from "next/link";

export default function AuthForm({mode}:{mode:"signup"|"login"}) {
 const [name,setName]=useState(""); const [email,setEmail]=useState(""); const [password,setPassword]=useState(""); const [confirm,setConfirm]=useState(""); const [terms,setTerms]=useState(false); const [msg,setMsg]=useState(""); const [loading,setLoading]=useState(false); const router=useRouter(); const supabase=createClient();
 async function submit(e:React.FormEvent){e.preventDefault();setMsg("");setLoading(true);
  if(mode==="signup"){ if(password!==confirm){setMsg("Passwords do not match.");setLoading(false);return} if(!terms){setMsg("Please accept the Terms & Risk Disclaimer.");setLoading(false);return}
    const {data,error}=await supabase.auth.signUp({email,password,options:{data:{full_name:name},emailRedirectTo:`${window.location.origin}/auth/callback`}}); if(error){setMsg(error.message);setLoading(false);return}
    setMsg(data.session?"Account created.":"Check your email to verify your account, then log in."); setLoading(false);
  } else { const {error}=await supabase.auth.signInWithPassword({email,password}); if(error){setMsg(error.message);setLoading(false);return} router.push("/dashboard"); router.refresh(); }
 }
 return <form onSubmit={submit}><>{mode==="signup"&&<input value={name} onChange={e=>setName(e.target.value)} placeholder="Full name" required/>}</><input value={email} onChange={e=>setEmail(e.target.value)} type="email" placeholder="Email address" required/><input value={password} onChange={e=>setPassword(e.target.value)} type="password" placeholder="Password (8+ characters)" minLength={8} required/>{mode==="signup"&&<><input value={confirm} onChange={e=>setConfirm(e.target.value)} type="password" placeholder="Confirm password" minLength={8} required/><label><input type="checkbox" checked={terms} onChange={e=>setTerms(e.target.checked)}/> I agree to the Terms & Risk Disclaimer.</label></>}<button className="btn gold full" disabled={loading}>{loading?"Please wait…":mode==="signup"?"Create Account":"Login"}</button><small>{mode==="signup"?<>Already have an account? <Link href="/login">Login</Link></>:<>New here? <Link href="/signup">Create an account</Link></>}</small><div>{msg}</div></form>
}
