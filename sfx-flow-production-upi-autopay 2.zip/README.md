# SFX FLOW — Production Membership Starter

## What is real here
- Supabase email/password authentication
- Email verification callback
- Server-side membership records
- Razorpay recurring subscription creation
- 7-day trial implemented with Razorpay `start_at`
- Server-side subscription authorization signature verification
- Razorpay webhook signature verification
- Webhook updates to membership status
- ₹199 Basic and ₹299 Premium plan IDs via environment variables

## What you must configure
1. Create a Supabase project and run `supabase.sql`.
2. Enable Email auth and configure your email redirect URL.
3. Create a Razorpay account and enable Subscriptions/recurring methods.
4. Create two monthly plans: ₹199 and ₹299. Put their Plan IDs into the env file.
5. Configure a public HTTPS webhook at `/api/razorpay/webhook`.
6. Use Test Mode first, then switch to Live keys only after testing.
7. Deploy to Vercel/another HTTPS host and set all environment variables.

## Important
The supplied personal UPI QR is not used for automated membership activation. A static QR cannot prove that a specific user paid. For automatic activation/renewal, use Razorpay Subscriptions. The QR can remain as a separate manual-payment fallback, but manual payments require verification.

Never expose `RAZORPAY_KEY_SECRET`, `RAZORPAY_WEBHOOK_SECRET`, or the Supabase service-role key in browser code or a public repository.

This project is an engineering starter, not legal/financial/compliance advice. Before public launch, confirm that the business model, disclosures, payment account and any trading-analysis/signal service comply with the laws and platform/payment-provider rules applicable to your customers.


## Official payment flow
The production starter now treats **Razorpay + UPI AutoPay** as the official membership payment path. The checkout button is labelled “Continue with UPI AutoPay”; Razorpay Checkout handles the actual UPI app/mandate flow. Eligible customers can be routed to supported UPI apps such as Google Pay, PhonePe or Paytm.

### Before launch
1. Create Basic and Premium monthly Plans in Razorpay and copy their Plan IDs into the environment variables.
2. Enable Subscriptions / UPI AutoPay on the Razorpay merchant account if required.
3. Configure the Razorpay webhook URL to `/api/razorpay/webhook` and use the webhook secret in `RAZORPAY_WEBHOOK_SECRET`.
4. Keep `RAZORPAY_KEY_SECRET` and `SUPABASE_SERVICE_ROLE_KEY` server-side only.
5. Run Razorpay test-mode checkout before switching to live keys.

The website does not directly integrate a personal Google Pay UPI ID. It uses Razorpay as the merchant/payment layer so payment verification and recurring membership status can be automated.
