import Link from "next/link";

export default function Home() {
  return <>
    <section className="hero">
      <div><span className="eyebrow">SFX FLOW • TRADE THE FLOW</span>
        <h1>Trade with a plan.<br/><span>Follow the flow.</span></h1>
        <p>Market analysis, trading tools and structured education for traders who want a cleaner way to study the markets.</p>
        <div className="row"><Link className="btn gold" href="/signup">Start 7-Day Free Trial</Link><Link className="btn outline" href="/#analysis">Explore Analysis</Link></div>
        <small>Educational content only. Trading involves substantial risk.</small>
      </div>
      <div className="terminal"><div className="terminal-head"><b>MARKET FLOW</b><span>● LIVE</span></div><div className="chart">{Array.from({length:10}).map((_,i)=><i key={i}/>)}</div><div className="quote"><div><small>XAU/USD</small><strong>Gold</strong></div><em>Market Watch</em></div></div>
    </section>
    <section id="markets" className="section"><div className="section-title"><div><span className="eyebrow">MARKETS</span><h2>Watch what matters.</h2></div><p>Keep your market focus in one place.</p></div><div className="cards four">{["XAU/USD|Gold","BTC/USD|Bitcoin","EUR/USD|Euro / Dollar","GBP/USD|Pound / Dollar"].map(x=>{const [a,b]=x.split("|");return <article key={a}><span>{a}</span><h3>{b}</h3><small>Analysis</small></article>})}</div></section>
    <section id="analysis" className="section split"><div><span className="eyebrow">ANALYSIS</span><h2>Structured setups.<br/>No noise.</h2><p>Market context, timeframe, entry area, invalidation and targets. Educational analysis only.</p></div><article className="setup"><div className="between"><span>XAU/USD</span><b>PREMIUM</b></div><h3>Market Setup</h3><p><label>Bias</label><strong>Analysis</strong></p><p><label>Timeframe</label><strong>5M / 15M</strong></p><p><label>Risk</label><strong>Defined before entry</strong></p><Link className="btn outline" href="/pricing">Unlock with Premium</Link></article></section>
    <section id="tools" className="section"><span className="eyebrow">TOOLS</span><h2>Trade smarter. Calculate first.</h2><div className="cards three"><article><span>01</span><h3>Position Size</h3><p>Plan position size around account risk.</p></article><article><span>02</span><h3>Risk / Reward</h3><p>Compare potential targets against defined risk.</p></article><article><span>03</span><h3>Trading Journal</h3><p>Record setups, decisions and results.</p></article></div></section>
    <section id="academy" className="section academy"><span className="eyebrow">SFX FLOW ACADEMY</span><h2>Learn the process.<br/>Build the discipline.</h2><p>Market basics, risk management, psychology and structured analysis.</p><Link className="btn outline" href="/pricing">Explore Membership</Link></section>
    <section className="warning"><h3>⚠️ Risk Warning</h3><p>Trading forex, commodities, cryptocurrencies and other financial markets involves significant risk and may result in loss of capital. SFX FLOW provides educational content, market analysis and tools for informational purposes only. Nothing on this website is a guarantee of profit or a promise of future performance. Trade only with money you can afford to lose.</p></section>
  </>;
}
