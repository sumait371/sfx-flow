import { NextResponse } from "next/server";
import crypto from "crypto";
import { createClient } from "@/lib/supabase-server";
import { createAdminClient } from "@/lib/supabase-admin";

export async function POST(req:Request){
 const supabase=await createClient(); const {data:{user}}=await supabase.auth.getUser(); if(!user)return NextResponse.json({error:"Login required"},{status:401});
 const body=await req.json(); const paymentId=body.razorpay_payment_id; const subscriptionId=body.razorpay_subscription_id; const signature=body.razorpay_signature;
 if(!paymentId||!subscriptionId||!signature)return NextResponse.json({error:"Missing Razorpay fields"},{status:400});
 const expected=crypto.createHmac("sha256",process.env.RAZORPAY_KEY_SECRET!).update(`${paymentId}|${subscriptionId}`).digest("hex");
 const valid=crypto.timingSafeEqual(Buffer.from(expected),Buffer.from(signature));
 if(!valid)return NextResponse.json({error:"Invalid Razorpay signature"},{status:400});
 const admin=createAdminClient();
 const {error}=await admin.from("subscriptions").update({status:"authenticated",razorpay_payment_id:paymentId,razorpay_signature:signature,updated_at:new Date().toISOString()}).eq("user_id",user.id).eq("razorpay_subscription_id",subscriptionId);
 if(error)return NextResponse.json({error:"Could not save subscription"},{status:500});
 return NextResponse.json({ok:true});
}
