import { NextResponse } from "next/server";
import crypto from "crypto";
import { createAdminClient } from "@/lib/supabase-admin";

function verify(raw:string, sig:string, secret:string){
 const h=crypto.createHmac("sha256",secret).update(raw).digest("hex");
 return h.length===sig.length && crypto.timingSafeEqual(Buffer.from(h),Buffer.from(sig));
}

export async function POST(req:Request){
 const raw=await req.text(); const sig=req.headers.get("x-razorpay-signature")||"";
 if(!process.env.RAZORPAY_WEBHOOK_SECRET||!sig||!verify(raw,sig,process.env.RAZORPAY_WEBHOOK_SECRET)) return new NextResponse("invalid",{status:400});
 const event=JSON.parse(raw); const payload=event.payload||{};
 const sub=payload.subscription?.entity;
 const payment=payload.payment?.entity;
 const subscriptionId=sub?.id || payment?.subscription_id;
 if(subscriptionId){
  const admin=createAdminClient();
  const patch:any={updated_at:new Date().toISOString()};
  if(sub){
   patch.status=sub.status;
   patch.current_start=sub.current_start?new Date(sub.current_start*1000).toISOString():null;
   patch.current_end=sub.current_end?new Date(sub.current_end*1000).toISOString():null;
   patch.paid_count=sub.paid_count??null;
  }
  if(payment){patch.razorpay_payment_id=payment.id;}
  await admin.from("subscriptions").update(patch).eq("razorpay_subscription_id",subscriptionId);
 }
 return new NextResponse("ok",{status:200});
}
