import { NextResponse } from "next/server";
import { createClient } from "@/lib/supabase-server";
import { createAdminClient } from "@/lib/supabase-admin";
import { razorpay } from "@/lib/razorpay";
import { PLANS, type PlanKey } from "@/lib/plans";

export async function POST(req:Request){
 const supabase=await createClient(); const {data:{user}}=await supabase.auth.getUser(); if(!user)return NextResponse.json({error:"Login required"},{status:401});
 const body=await req.json(); const plan=body.plan as PlanKey; if(!PLANS[plan])return NextResponse.json({error:"Invalid plan"},{status:400});
 const planId=process.env[PLANS[plan].env]; if(!planId)return NextResponse.json({error:"Razorpay plan is not configured yet."},{status:500});
 const trialEnd=Math.floor(Date.now()/1000)+7*24*60*60;
 const rp=razorpay();
 const sub=await rp.subscriptions.create({plan_id:planId,total_count:1200,quantity:1,start_at:trialEnd,customer_notify:1,notes:{user_id:user.id,plan,payment_method:"upi_autopay"}});
 const admin=createAdminClient();
 await admin.from("subscriptions").upsert({user_id:user.id,plan_key:plan,plan_name:PLANS[plan].name,razorpay_subscription_id:sub.id,status:"created",trial_end_at:new Date(trialEnd*1000).toISOString(),updated_at:new Date().toISOString()},{onConflict:"razorpay_subscription_id"});
 return NextResponse.json({subscriptionId:sub.id,key:process.env.RAZORPAY_KEY_ID,planName:PLANS[plan].name,name:user.user_metadata?.full_name||"",email:user.email});
}
