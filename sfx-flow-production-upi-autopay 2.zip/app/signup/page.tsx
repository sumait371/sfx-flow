import AuthForm from "@/components/auth-form";
export default function Signup(){return <section className="auth"><div><span className="eyebrow">JOIN SFX FLOW</span><h2>Create your account.</h2><p>7-day trial • Email-based signup • No mobile number required.</p></div><AuthForm mode="signup"/></section>}
