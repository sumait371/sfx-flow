import { createClient } from "@/lib/supabase-server";
import { redirect } from "next/navigation";
import SubscriptionButton from "@/components/subscription-button";

export default async function Dashboard(){
 const supabase=await createClient(); const {data:{user}}=await supabase.auth.getUser(); if(!user) redirect("/login");
 const {data:sub}=await supabase.from("subscriptions").select("*").eq("user_id",user.id).order("created_at",{ascending:false}).limit(1).maybeSingle();
 const trialEnd=sub?.trial_end_at?new Date(sub.trial_end_at):null; const now=new Date(); const trialActive=trialEnd?trialEnd>now:false;
 return <section className="dash"><div className="dash-top"><div><span className="eyebrow">MEMBER DASHBOARD</span><h2>Welcome, {user.user_metadata?.full_name||user.email?.split("@")[0]}.</h2><p>{trialActive?`Your free trial ends ${trialEnd?.toLocaleDateString("en-IN")}.`:"Choose a plan to unlock membership."}</p></div></div>
 <div className="cards three"><article className="status"><span>MEMBERSHIP</span><h3>{sub?.plan_name||"7-Day Trial"}</h3><p>Status: {sub?.status||"trial"}</p></article><article className="status"><span>MARKET FOCUS</span><h3>XAU/USD</h3><p>Gold analysis</p></article><article className="status"><span>PAYMENT</span><h3>{sub?.razorpay_subscription_id?"Razorpay linked":"Not linked"}</h3><p>Recurring billing</p></article></div>
 <div className="member-box"><h3>Membership</h3><p>Premium content is unlocked from the server-side membership record after verified Razorpay events. Do not rely on browser-only payment success.</p>{!sub?.razorpay_subscription_id&&<SubscriptionButton plan="premium"/>}</div></section>
}
