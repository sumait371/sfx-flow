import AuthForm from "@/components/auth-form";
export default function Login(){return <section className="auth"><div><span className="eyebrow">WELCOME BACK</span><h2>Log in to SFX FLOW.</h2><p>Access your member dashboard.</p></div><AuthForm mode="login"/></section>}
