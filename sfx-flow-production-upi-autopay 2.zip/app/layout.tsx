import "./globals.css";
import Link from "next/link";

export const metadata = {
  title: "SFX FLOW — Trade the Flow",
  description: "SFX FLOW trading education, analysis and tools."
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>
        <header className="nav">
          <Link href="/" className="brand"><img src="/sfx-flow-logo.png" alt="SFX FLOW" /></Link>
          <nav>
            <Link href="/#markets">Markets</Link>
            <Link href="/#analysis">Analysis</Link>
            <Link href="/#tools">Tools</Link>
            <Link href="/#academy">Academy</Link>
            <Link href="/pricing">Pricing</Link>
          </nav>
          <div className="actions">
            <Link href="/login">Login</Link>
            <Link className="btn gold" href="/signup">Start Free Trial</Link>
          </div>
        </header>
        {children}
        <footer><img src="/sfx-flow-logo.png" alt="SFX FLOW" /><span>© 2026 SFX FLOW — Trade the Flow.</span><span>Educational purposes only.</span></footer>
      </body>
    </html>
  );
}
